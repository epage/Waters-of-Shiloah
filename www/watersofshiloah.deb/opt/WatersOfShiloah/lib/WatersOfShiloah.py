#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys

sys.path.append('/opt/WatersOfShiloah/lib')


import watersofshiloah_gtk


if __name__ == "__main__":
	watersofshiloah_gtk.run()
